<?php
defined('_JEXEC') or die;
$app  = JFactory::getApplication();
var_dump($app);
?>